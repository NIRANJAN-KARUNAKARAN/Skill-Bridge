# SkillBridge — Frontend

Frontend UI for **SkillBridge: Intelligent Job Market & Skill-Gap Analysis Platform**
(India vs Malaysia), built from the internship briefing deck's Final Product scope:

- Job explorer and filters
- Skills demand dashboard
- India–Malaysia comparison view
- Skill-gap checker
- Country dashboards / overview

The data shown is pulled from the project's own cleaned datasets
(`SkillBridge_Unified_India_Malaysia.xlsx`) — real role, skill, location and salary
figures aggregated into `src/data/skillbridgeData.js`, plus an 80-listing sample for
the job explorer. Swap that file for a live API response once the backend (G2‑A) is
ready — every page reads from that single module.

## Stack

- React 18 + Vite
- Tailwind CSS (dark, data-forward theme — see `tailwind.config.js` for the token set)
- React Router (client-side navigation between the five views)
- Recharts (bar charts, radial match-score gauge)

## Run it

```bash
npm install
npm run dev
```

Then open the printed local URL (defaults to `http://localhost:5173`).

## Build for deployment

```bash
npm run build
```

Outputs a static `dist/` folder — deployable to Streamlit Community Cloud's static
hosting, Render's static site, GitHub Pages, or any static host, per the deck's
"Free Tools / Deploy" slide.

## Project structure

```
src/
  components/     Sidebar, page header, shared UI (cards, chips, split bars), icons
  pages/          Dashboard, JobExplorer, SkillsDemand, Comparison, SkillGap
  data/           skillbridgeData.js — the dataset the whole UI reads from
  App.jsx         Route table
  main.jsx        Entry point
```

## Wiring up the real backend

Each page imports one object, `skillbridgeData`, from `src/data/skillbridgeData.js`.
To connect G2‑A's REST API once it's live, replace that static import with fetch calls
(e.g. in a small `src/api/` layer) returning the same shape:

- `summary` — `{ totalJobs, indiaJobs, malaysiaJobs }`
- `topRoles` — `[{ role, india, malaysia, total }]`
- `topSkillsIndia` / `topSkillsMalaysia` — `[{ skill, count }]`
- `topLocationsIndia` / `topLocationsMalaysia` — `[{ location, count }]`
- `roleDetails` — `{ [role]: { requiredSkills, indiaJobs, malaysiaJobs, avgSalaryIndia, avgSalaryMalaysia } }`
- `jobs` — `[{ title, company, location, country, role, experience, minSalary, maxSalary, currency, skills }]`

No page-level code needs to change beyond that swap.
